//
//  klarkAppDelegate.h
//  replaceString
//
//  Created by 易礼明 on 14-7-14.
//  Copyright (c) 2014年 tencent. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface klarkAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
