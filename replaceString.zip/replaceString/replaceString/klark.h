//
//  klark.h
//  replaceString
//
//  Created by 易礼明 on 14-7-15.
//  Copyright (c) 2014年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface klark : NSObject
-(NSString *)extractString:(NSString *)str;
-(NSString *)replacefirstblank:(NSString *)str1 match:(NSString *)str2 string:(NSString *)str3;
//-(IBAction)showAlert;
@end
