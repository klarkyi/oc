//
//  klarkViewController.h
//  replaceString
//
//  Created by 易礼明 on 14-7-14.
//  Copyright (c) 2014年 tencent. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface klarkViewController : UIViewController
@property IBOutlet UILabel *lable;
@property IBOutlet UITextField *textfild1;
@property IBOutlet UITextField *textfild2;
@property IBOutlet UITextField *textfild3;
-(IBAction)repalce:(id)sender;
-(IBAction)tap:(id)sender;
@end
