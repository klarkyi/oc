//
//  main.m
//  replaceString
//
//  Created by 易礼明 on 14-7-14.
//  Copyright (c) 2014年 tencent. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "klarkAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([klarkAppDelegate class]));
    }
}
